import os
import argparse
from typing import List

FFMPEG = r"ffmpeg.exe"

class Film:
    def __init__(self, video: str, subtitle=None, subtitle_font=None, subtitle_size:int=30, start:str="0"):
        self.video = video
        self.subtitle = subtitle
        self.subtitle_font = subtitle_font
        self.subtitle_size = subtitle_size
        self.start = start

    def get_subtitle_string(self):
        # subtitles='{subtitles}':force_style='FontName=ubuntu,Fontsize=30'
        if not self.subtitle:
            return ""
        subtitles = self.subtitle.replace("\\", "/").replace(":", "\\:")            
        data = [f"subtitles='{subtitles}'"]
        if self.subtitle_font:
            data.append(f":force_style='FontName=ubuntu,Fontsize={self.subtitle_size}")
        return "".join(data)

# Z:\Stuff\pyconvert\bin\ffmpeg -re -i "$_" -vcodec libx264 -vprofile baseline -g 30 -acodec aac -strict -2 -f flv rtmp://localhost/live/mystream
class FFMPEG_STREAMER:
    ARGS = ["-vcodec", "libx264",
            "-vprofile", "baseline", 
            "-g", "30", 
            "-acodec", "aac",         
            "-strict", "2", 

            # To suppport 10bit hevc : https://github.com/donmelton/other_video_transcoding/issues/73
            "-vf", "format=yuv420p",
            "-f", "flv",
            # Normalize volume
            "-af", "loudnorm=I=-16:LRA=11:TP=-1.5",
            #"-af", "loudnorm"
            ]

    def __init__(self, ffmpeg_path: str, stream_path: str):
        self.ffmpeg = ffmpeg_path
        self.stream_path = stream_path

    def stream_file(self, video: Film, destionation: str):
        args = self.ARGS.copy()
        if video.subtitle:
            
            args[11] = args[11] +  f",{video.get_subtitle_string()}"
        postargs = " ".join(args)
        url = self.stream_path + destionation
        cmd = f"{self.ffmpeg} -ss {video.start} -copyts -re -i \"{video.video}\" -ss {video.start} {postargs} {url}"
        print("CMD: "+cmd)
        os.system(cmd)

def main():
    args = parse_args()
    streamer = FFMPEG_STREAMER(args.ffmpeg, args.stream)

    videos: List[Film] = []
    if args.videos:
        for film in args.videos:
            f = Film(film)
            if args.subtitle:
                f.subtitle = args.subtitle
            if args.subtitle_size:
                f.subtitle_font = args.subtitle_font
                f.subtitle_size = args.subtitle_size
            videos.append(f)

    if args.fromfile:
        with open(args.fromfile) as f:
            vids = [x.strip() for x in f.readlines() if x.strip()]
            videos.extend(Film(v) for v in vids)

    if videos:
        for video in videos:
            streamer.stream_file(video, args.key)
        if args.repeat:
            while True:
                for video in videos:
                    streamer.stream_file(video, args.key)


def parse_args():
    parser = argparse.ArgumentParser(description='Stream some files')
    parser.add_argument('videos', metavar='V', nargs='*', help='File(s) to stream')
    parser.add_argument('--stream', help='Stream target name', default="rtmp://localhost/live/")
    parser.add_argument('--key', help='Stream target key', default="mystream")
    parser.add_argument('--ffmpeg', help="FFMPEG exe", default=FFMPEG)
    parser.add_argument('--fromfile', help="File with video list")
    parser.add_argument("--subtitle", help="Subtitle file")
    parser.add_argument("--subtitle_size", help="Subtitle font size")
    parser.add_argument("--subtitle_font", help="Subtitle font", default="Ubuntu")
    parser.add_argument('--repeat', help="Repeat movie list", default=False, action="store_true")
    
    return parser.parse_args()

if __name__ == "__main__":
    main()